from django import forms

from gateway.models import Gateway

class FlatGatewayForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = Gateway
        exclude = ('gCreatedBy', 'gCreatedDate',
                   'gUpdatedBy', 'gUpdatedDate','gStatus')
