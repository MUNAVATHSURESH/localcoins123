from django.shortcuts import render

# Create your views here.
def gatewayPages(request):
    return render(request,'gateway/flatgateway.html')