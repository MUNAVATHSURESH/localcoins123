from datetime import datetime
from django.db import models
from user.models import User
# Create your models here.
class Gateway(models.Model):
    gName = models.CharField(max_length=30, primary_key=True)
    gSlug = models.CharField(max_length=30, null=False)
    gStatus = models.IntegerField(default=1, null=False)
    gCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    gCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    gUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    gUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
