from django.contrib import admin
from user.models import User

# Register your models here.
class UserAdmin(admin.ModelAdmin):
    list_display=[
        'uUserName',
        'uFirstName',
        'uLastName',
        'uEmail',
        'uContact',
        'uAvatar',
        'uAddress',
        'uCity',
        'uState',
        'uZipCode',
        'uCountry',
        'uEmailVarified',
        'uSmsVerified',
        'u2FAStatus',
        'u2FAVarifStatus',
        'uStatus',
        'uCreatedBy',
        'uCreatedDate',
        'uUpdatedBy',
        'uUpdatedDate'
    ]

admin.site.register(User,UserAdmin)