
from dataclasses import fields
from user.models import User
from django import forms

class UserForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = User
        exclude = ('ccCreatedBy', 'ccCreatedDate',
                   'ccUpdatedBy', 'ccUpdatedDate','ccStatus')
                   

class SignUPForm(forms.ModelForm):
    class Meta:
        model = User
        fields = {'uUserName', 'uFirstName',
                   'uLastName', 'uEmail', 'uContact', 'uCountry','password'}


class LoginForm(forms.ModelForm):
    class Meta:
        model = User
        fields = {'uUserName', 'password'}
