from datetime import datetime
from django.db import models
from django.contrib.auth.models import AbstractUser

from user.manager import UserManager
# Create your models here.
class User(AbstractUser):
    username = None
    uUserName = models.CharField(max_length=30, primary_key=True)
    uFirstName = models.CharField(max_length=50, null=False)
    uLastName = models.CharField(max_length=50, null=False)
    uEmail = models.EmailField(unique=True, null=False)
    uContact = models.CharField(max_length=30, null=False)
    uAvatar = models.ImageField(null=True, upload_to="media/")
    uAddress = models.CharField(max_length=30, null=True)
    uCity = models.CharField(max_length=30, null=True)
    uState = models.CharField(max_length=30, null=True)
    uZipCode = models.CharField(max_length=30, null=True)
    uCountry = models.CharField(max_length=30, null=True)
    uEmailVarified = models.BooleanField(default=False)
    uSmsVerified = models.BooleanField(default=False)
    u2FAStatus = models.BooleanField(default=False)
    u2FAVarifStatus = models.BooleanField(default=False)
    uStatus = models.IntegerField(default=1, null=False)
    uCreatedBy = models.CharField(max_length=50, null=False)
    uCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    uUpdatedBy = models.CharField(max_length=50, null=True)
    uUpdatedDate = models.DateTimeField(default=datetime.now, null=True)

    USERNAME_FIELD = 'uUserName'
    REQUIRED_FIELDS = ['uEmail']

    objects = UserManager()

    class Meta:
        db_table = 'USERS'
