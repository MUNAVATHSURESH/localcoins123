from datetime import datetime
from django.shortcuts import redirect, render
from django.db.models import Q
from advertisement.models import Advertisement
from cryptocurrency.models import CryptoCurrency
from flatcurrency.models import FlatCurrency
from gateway.models import Gateway
from traderequest.models import TradeRequest
from user.forms import LoginForm
from user.forms import SignUPForm, UserForm
from wallet.models import Wallet

from django.contrib.auth import authenticate, login, logout
from user.models import User
from django.contrib.auth.decorators import login_required

# Create your views here.



def getHome(request):
    cryptoCurr = CryptoCurrency.objects.all()
    gatewayType = Gateway.objects.all()
    flatCurr = FlatCurrency.objects.all()   
    return render(request, 'user/index.html', {'ccList': cryptoCurr, 'gT': gatewayType, 'fC': flatCurr})


@login_required
def getUserDashboard(request):
    uAds = Advertisement.objects.filter(aCreatedBy__uUserName=request.user.uUserName)
    cryptoCurr = CryptoCurrency.objects.all()
    walletSets = Wallet.objects.filter(wUser__uUserName=request.user.uUserName)
    adsCount = uAds.count()
    user = User.objects.get(pk=request.user.uUserName)
    tradeRequest = TradeRequest.objects.filter(
        tCreatedBy__uUserName=request.user.uUserName)
    my_dict1 = {'uAdvertisement': uAds,
                'ccList': cryptoCurr, 'walletSets': walletSets, 'adsCount': adsCount, 'user': user, 'trCount': tradeRequest.count(), 'trCompletedCount': tradeRequest.filter(tStatus=18).count()}
    return render(request, 'user/dashboarduser.html', context=my_dict1)

# Create your views here.
def registerUser(request):
    if request.method == "POST":
        form = SignUPForm(request.POST)
        if form.is_valid():
            uSaved = form.save(commit=False)
            time = datetime.now()
            uSaved.uCreatedBy = "SYSTEM"
            uSaved.uCreatedDate = time
            uSaved.uStatus = 1
            uSaved.set_password(uSaved.password)
            uSaved.save()
            return redirect('login')
    form = SignUPForm()
    return render(request, 'user/register.html', {'form': form})



# Create your views here.
def loginUser(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        print('username', username, 'password', password)
        user = User.objects.get(pk=username)
        if user.check_password(password):
            login(request,user)
            print('username', username, 'password', password)
            return redirect('dashboardU')
    return render(request,'user/login.html')

@login_required
def getUserAds(request):
    uAdsList = Advertisement.objects.filter(
        aCreatedBy__uUserName=request.user.uUserName)
    ccList = CryptoCurrency.objects.all()
    return render(request, 'user/userAds.html', {'uAdsList': uAdsList,'ccList':ccList})


def logoutUser(request):
    logout(request)
    return redirect('home')
