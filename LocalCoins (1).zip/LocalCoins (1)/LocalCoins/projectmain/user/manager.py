from django.contrib.auth.models import (
	BaseUserManager, AbstractUser
)


class UserManager(BaseUserManager):
	use_in_migrations = True

	def create_user(self, uUserName, uEmail, password=None, **extra_fields):
		"""
		creates a user with given email and password
		"""
		if not uUserName:
			raise ValueError('user must have a username')

		if not uEmail:
			raise ValueError('user must have a email address')

		user = self.model(
			uUserName=self.normalize_email(uUserName),
			uEmail=self.normalize_email(uEmail),
			**extra_fields
		)

		user.set_password(password)
		user.save(self._db)
		return user

	# def create_staffuser(self, uUserName, uEmail, password, **extra_fields):
	# 	"""
	# 	creates a user with staff permissions
	# 	"""
	# 	user = self.create_user(
	# 		uUserName=uUserName,
	# 		uEmail=uEmail,
	# 		password=password,
	# 		**extra_fields
	# 	)
	# 	#user.staff = True
	# 	user.save(using=self._db)
	# 	return user

	def create_superuser(self, uUserName, uEmail, password, **extra_fields):
		"""
		creates a superuser with email and password
		"""
		extra_fields.setdefault('is_staff', True)
		extra_fields.setdefault('is_superuser', True)
		extra_fields.setdefault('is_active', True)

		if extra_fields.get('is_staff') is not True:
			raise ValueError('user must be logged in with staff (is_staff is false)')

		user = self.create_user(
			uUserName=uUserName,
			uEmail=uEmail,
			password=password,
			**extra_fields
		)
		#user.staff = True
		#user.admin = True
		user.save(using=self._db)
		return user
