from user import views
from advertisement import views as adView
from traderequest import views as trView
from wallet import views as wView
from transaction import views as trnView
from traderequest import views as trdView
from django.urls import path

urlpatterns = [
    path('h/', views.getHome, name="home"),
    path('dashboard/', views.getUserDashboard, name="dashboardU"),
    path('r/', views.registerUser, name="register"),
    path('login/', views.loginUser, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('ads/', views.getUserAds, name="userAds"),
    path('ads/a/', adView.saveUserAds, name="userNewAds"),
    path('tr/', trView.getUserTradeRequest, name="userTradeRequest"),
    path('w/', wView.getUserWallet, name="userWallet"),
    path('trn/', trnView.getUserTransaction, name="userTrns"),
    path('trd/a/<slug:id>', trdView.newTradeRequest, name="userNewTrade"),
    path('trd/trn/<slug:id>', trdView.payTradeRequest, name="userPayTrade"),
    path('trd/tRec/<slug:id>', trdView.generateTradeReciept, name="userGenTradeReciept"),

    
]
