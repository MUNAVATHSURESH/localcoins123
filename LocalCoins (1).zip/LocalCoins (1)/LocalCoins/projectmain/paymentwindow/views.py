from django.shortcuts import render

# Create your views here.
def paymentWindowurl(request):
    return render(request,'paymentwindow/payment_window.html')