from datetime import datetime
from django.db import models
from user.models import User

# Create your models here.
class PaymentWindow(models.Model):
    pMinute = models.IntegerField(primary_key=True)
    pStatus = models.IntegerField(default=1, null=False)
    pCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    pCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    pUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    pUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
