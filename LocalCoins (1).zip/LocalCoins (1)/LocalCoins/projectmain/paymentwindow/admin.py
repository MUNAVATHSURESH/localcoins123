from django.contrib import admin

from paymentwindow.models import PaymentWindow

# Register your models here.


class PaymentWindowAdmin(admin.ModelAdmin):
    list_display = [
        'pMinute',
        'pStatus',
        'pCreatedBy',
        'pCreatedDate',
        'pUpdatedBy',
        'pUpdatedDate',
    ]


admin.site.register(PaymentWindow, PaymentWindowAdmin)
