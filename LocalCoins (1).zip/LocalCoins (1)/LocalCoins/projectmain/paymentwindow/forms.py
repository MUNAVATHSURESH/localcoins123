from django import forms

from paymentwindow.models import PaymentWindow

class PaymentWindowForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = PaymentWindow
        exclude = ('pCreatedBy', 'pCreatedDate',
                   'pUpdatedBy', 'pUpdatedDate','pStatus')
                   