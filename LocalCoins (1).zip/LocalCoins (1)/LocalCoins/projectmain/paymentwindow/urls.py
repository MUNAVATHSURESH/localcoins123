from paymentwindow import views
from django.urls import path

urlpatterns = [
    
    path('paymentWindowurl/', views.paymentWindowurl),
]
