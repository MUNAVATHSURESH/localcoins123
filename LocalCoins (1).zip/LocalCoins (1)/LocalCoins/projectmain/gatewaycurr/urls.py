from gatewaycurr import views
from django.urls import path

urlpatterns = [
    
    path('gatewayCurrurl/', views.gatewayCurrPages),
]
