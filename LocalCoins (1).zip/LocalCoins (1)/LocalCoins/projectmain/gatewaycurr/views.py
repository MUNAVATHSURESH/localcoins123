from django.shortcuts import render

# Create your views here.
def gatewayCurrPages(request):
    return render(request,'advertisement/home.html')