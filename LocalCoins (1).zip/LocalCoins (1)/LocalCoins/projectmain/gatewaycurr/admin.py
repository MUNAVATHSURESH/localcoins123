from django.contrib import admin

from gatewaycurr.models import GatewayCurr

# Register your models here.


class GatewayCurrAdmin(admin.ModelAdmin):
    list_display = [
        'gcName',
        'gcCCurency',
    ]
admin.site.register(GatewayCurr, GatewayCurrAdmin)
