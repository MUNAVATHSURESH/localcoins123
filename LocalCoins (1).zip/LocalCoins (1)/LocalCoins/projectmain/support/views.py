from datetime import datetime
from django.shortcuts import render, redirect
from cryptocurrency.models import CryptoCurrency
from user.models import User

from support.form import SuppportForm

# Create your views here.


def getAllSupports(request):
    ccList = CryptoCurrency.objects.all()
    return render(request, 'support/all_ticket.html', {'ccList': ccList})


def submitSupport(request):
    form = SuppportForm(request.POST, request.FILES)
    ccList = CryptoCurrency.objects.all()
    if request.method == "POST":
        form = SuppportForm(request.POST)
        if form.is_valid():
            sSaved = form.save(commit=False)
            sSaved.sCreatedBy = User.objects.get(uUserName="SYSTEM")
            sSaved.sCreatedDate = datetime.now()
            sSaved.sStatus = 1
            sSaved.save()
            return redirect('home')
    return render(request,'support/contact.html',{'form':form,'ccList':ccList})



    