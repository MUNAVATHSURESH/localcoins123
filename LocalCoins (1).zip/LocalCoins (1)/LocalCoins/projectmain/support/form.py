
from django import forms
from cryptocurrency.models import CryptoCurrency
from support.models import Support


class SuppportForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = Support
        fields = ('sName', 'sEmail',
                  'sSubject', 'sMessage')


                   
