from django.contrib import admin

from support.models import Support

# Register your models here.


class SupportAdmin(admin.ModelAdmin):
    list_display = [
        'sName',
        'sEmail',
        'sSubject',
        'sPriority',
        'sMessage',
        'sAttachment',
        'sStatus',
        'sCreatedBy',
        'sCreatedDate',
        'sUpdatedBy',
        'sUpdatedDate',
    ]
admin.site.register(Support, SupportAdmin)
