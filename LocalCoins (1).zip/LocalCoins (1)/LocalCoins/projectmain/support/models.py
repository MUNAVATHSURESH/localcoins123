from datetime import datetime
from django.db import models

from user.models import User

# Create your models here.
class Support(models.Model):
    sName = models.CharField(max_length=100, null=False)
    sEmail = models.EmailField(unique=True, null=False)
    sSubject = models.CharField(max_length=50, null=False)
    sPriority = models.IntegerField(null=True)
    sMessage = models.CharField(max_length=100, null=False)
    sAttachment = models.FileField(null=True)
    sStatus = models.IntegerField(default=1, null=False)
    sCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    sCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    sUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    sUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
