from support import views
from django.urls import path

urlpatterns = [
    
    path('', views.getAllSupports),
    path('a/', views.submitSupport, name="contact"),
]
