from transaction import views
from django.urls import path

urlpatterns = [
    
    path('transactionurl/', views.transactionPages),
    path('pendinglogurl/', views.pendinglogPages),
]
