from django.shortcuts import render
from cryptocurrency.models import CryptoCurrency

from transaction.models import Transaction

from django.contrib.auth.decorators import login_required

# Create your views here.
def transactionPages(request):
    return render(request,'transaction/deposit.html')


def pendinglogPages(request):
    return render(request,'transaction/pending_log.html')


@login_required
def getUserTransaction(request):
    trns = Transaction.objects.filter(trUser__uUserName=request.user.uUserName)
    ccList = CryptoCurrency.objects.all()
    return render(request, 'user/userTransaction.html',{'trns':trns,'ccList':ccList})
