from datetime import datetime
from django.db import models
from cryptocurrency.models import CryptoCurrency
from trnType.models import TransactionType

from user.models import User

# Create your models here.
class Transaction(models.Model):
    trUser = models.ForeignKey(
        User, on_delete=models.CASCADE,  null=False)
    trCode = models.CharField(max_length=100, null=False)
    trCCurrency = models.ForeignKey(
        CryptoCurrency, on_delete=models.CASCADE, null=False)
    trAmount = models.FloatField(null=True)
    trPostBalance = models.FloatField(null=True)
    trDetails = models.CharField(max_length=100, null=False)
    trType = models.ForeignKey(
        TransactionType, on_delete=models.CASCADE, null=False)
    trAction = models.BooleanField(null=True)
    trCharge = models.FloatField(default = 0.0,null=False)
    trStatus = models.IntegerField(default=1, null=False)
    trCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    trCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    trUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    trUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
