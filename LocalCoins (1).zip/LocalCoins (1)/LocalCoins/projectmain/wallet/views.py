from django.shortcuts import render
from django.db.models import Count
from cryptocurrency.models import CryptoCurrency
from wallet.models import Wallet
from django.db.models import Sum
from django.contrib.auth.decorators import login_required

# Create your views here.
def walletPages(request):
    return render(request,'advertisement/home.html')


@login_required
def getUserWallet(request):
    wallet = Wallet.objects.filter(wUser__uUserName=request.user.uUserName)
    walletCurrency = wallet.values("wCCurrency").order_by("wCCurrency").annotate(
        ccCount=Count('wCCurrency'))
    walletTotalAmount = wallet.values("wCCurrency").order_by("wCCurrency").aggregate(
        totalAmt=Sum('wCCAmount')
    )
    walletCurrencyAmount = wallet.values("wCCurrency").order_by("wCCurrency").annotate(
        totalAmt=Sum('wCCAmount')
    )
    ccList = CryptoCurrency.objects.all()
    # for w in walletCurrency:
    #     print(w['wCCurrency'])
    return render(request, 'user/userWallets.html', {'wallet': wallet, 'ccList': ccList, 'walletCurrency': walletCurrency, 'walletCurrencyAmount': walletCurrencyAmount, 'walletCurrencyAmount': walletCurrencyAmount,'walletTotalAmount': walletTotalAmount})
