from wallet import views
from django.urls import path

urlpatterns = [
    
    path('walleturl/', views.walletPages),
    path('walletadd/', views.walletPages),
]
