from django.contrib import admin

from wallet.models import Wallet

# Register your models here.
class WalletAdmin(admin.ModelAdmin):
    list_display=[
        'wCCurrency',
        'wCCAmount',
        'wUser',
        'wAddress',
        'wStatus',
        'wCreatedBy',
        'wCreatedDate',
        'wUpdatedBy',
        'wUpdatedDate',
    ]

admin.site.register(Wallet, WalletAdmin)