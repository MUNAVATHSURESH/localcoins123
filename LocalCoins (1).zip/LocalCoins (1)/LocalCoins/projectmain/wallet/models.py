from datetime import datetime
from django.db import models

from cryptocurrency.models import CryptoCurrency
from user.models import User

# Create your models here.
class Wallet(models.Model):
    wCCurrency = models.ForeignKey(
        CryptoCurrency, on_delete=models.CASCADE, null=False)
    wCCAmount = models.FloatField(null=False)
    wUser = models.ForeignKey(
        User, on_delete=models.CASCADE, null=False)
    wAddress = models.CharField(max_length=100, null=False)
    wStatus = models.IntegerField(default=1, null=False)
    wCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    wCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    wUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    wUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
    