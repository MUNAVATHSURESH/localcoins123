from django.shortcuts import redirect,render
from advertisement.models import Advertisement
from cryptocurrency.models import CryptoCurrency
from flatcurrency.models import FlatCurrency
from gateway.forms import FlatGatewayForm
from gateway.models import Gateway
from paymentwindow.forms import PaymentWindowForm
from paymentwindow.models import PaymentWindow
from user.forms import UserForm
from traderequest.models import TradeRequest
from transaction.models import Transaction
from user.models import User

from django.db.models import Sum
from django.db.models import Q
from datetime import datetime
from cryptocurrency.form import CryptoCurrencyForm

from datetime import datetime
from django.shortcuts import render
from django.db.models import Q
from flatcurrency.form import FlatCurrencyForm

from flatcurrency.models import FlatCurrency
from user.models import User
# Create your views here.


def getDashboard(request):
    userCount = User.objects.all().count()
    verifiedUserCount = User.objects.filter(Q(uEmailVarified=True) & Q(uSmsVerified=True)).count()
    emailVarfiedCount = User.objects.filter(uEmailVarified=True).count()
    smsVarifiedCount = User.objects.filter(uSmsVerified=True).count()
    adsCount = Advertisement.objects.all().count()
    tradeRequestCount = TradeRequest.objects.all().count()
    ccList = CryptoCurrency.objects.all()
    fcCount = FlatCurrency.objects.all().count()
    trns = Transaction.objects.all()
    crTrns=trns.filter(trType__trnType='CREDIT')
    crTotalAmount = crTrns.values("trCCurrency").order_by("trCCurrency").annotate(
        totalTrns=Sum('trAmount'))
    crTotalCharges= crTrns.values("trCCurrency").order_by("trCCurrency").annotate(
        totalChrg=Sum('trCharge'))
    drTrns = trns.filter(trType__trnType='DEBIT')
    drTotalAmount = drTrns.values("trCCurrency").order_by("trCCurrency").annotate(
        totalTrns=Sum('trAmount'))
    drTotalCharges = drTrns.values("trCCurrency").order_by("trCCurrency").annotate(
        totalChrg=Sum('trCharge'))

    print(crTotalAmount)
    print(crTotalCharges)
    
    return render(request, 'admin/dashboard.html',{'userCount':userCount,'verifiedUserCount':verifiedUserCount,
    'emailVarfiedCount':emailVarfiedCount,'smsVarifiedCount':smsVarifiedCount,'adsCount':adsCount,
    'tradeRequestCount':tradeRequestCount,'ccList':ccList,'fcCount':fcCount, 'crTotalAmount':crTotalAmount, 'crTotalCharges':crTotalCharges,
    'drTotalAmount': drTotalAmount, 'drTotalCharges': drTotalCharges})

def getActiveUsers(request):
    
    users =User.objects.filter(uStatus=1)
    if request.method == "POST":
        searchName = request.POST.get('search')
        users = User.objects.filter(
            Q(uUserName__icontains=searchName) | Q(uEmail__icontains=searchName))
    return render(request, 'admin/activeusers.html',{'uList':users})


def getBannedUsers(request):
    users =User.objects.filter(uStatus = 14)
    if request.method == "POST":
        searchName = request.POST.get('search')
        users = User.objects.filter(
            Q(uUserName__icontains=searchName) | Q(uEmail__icontains=searchName))
    return render(request, 'admin/bannedusers.html',{'uList':users})



def getEmailUnverified(request):
    users =User.objects.filter(uEmailVarified = False)
    if request.method == "POST":
        searchName = request.POST.get('search')
        users = User.objects.filter(
            Q(uUserName__icontains=searchName) | Q(uEmail__icontains=searchName))
    return render(request, 'admin/emailUnvarified.html',{'uList':users})

def getSmsUnverified(request):
    users =User.objects.filter(uSmsVerified = False)
    if request.method == "POST":
        searchName = request.POST.get('search')
        users = User.objects.filter(
            Q(uUserName__icontains=searchName) | Q(uEmail__icontains=searchName))
    return render(request, 'admin/smsUnverified.html',{'uList':users})


def getAllCCurrs(request):
    cryptoCurrs = CryptoCurrency.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        cryptoCurrs = CryptoCurrency.objects.filter(
            Q(ccName__icontains=searchName) | Q(ccCode__icontains=searchName))
        return render(request, 'admin/cryptocurrency.html', {'ccList': cryptoCurrs})
    return render(request, 'admin/cryptocurrency.html', {'ccList': cryptoCurrs})


def saveCCurr(request):
    if request.method == "POST":
        form = CryptoCurrencyForm(request.POST, request.FILES)
        if form.is_valid():
            ccSaved = form.save(commit=False)
            ccSaved.ccCreatedBy = User.objects.get(uUserName="SYSTEM")
            ccSaved.ccCreatedDate = datetime.now()
            ccSaved.ccStatus = 1
            ccSaved.save()
            return redirect('adminSearchCC')
    form = CryptoCurrencyForm()
    return render(request, 'admin/addCC.html', {'form': form})


def updateCCurr(request,id):
    cc = CryptoCurrency.objects.get(pk=id)
    if request.method == "POST":
        form = CryptoCurrencyForm(request.POST, request.FILES, instance=cc)       
        if form.is_valid():
            ccSaved = form.save(commit=False)
            ccSaved.ccUpdatedBy = User.objects.get(uUserName="SYSTEM")
            ccSaved.ccUpdatedDate = datetime.now()
            ccSaved.ccStatus = 1
            ccSaved.save()
            cryptoCurrs = CryptoCurrency.objects.all()
            return redirect('adminSearchCC')
    form = CryptoCurrencyForm()
    return render(request, 'admin/updateCC.html', {'form': form,'cc':cc})




def getAllFcurrs(request):
    flatCurrs = FlatCurrency.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        flatCurrs = FlatCurrency.objects.filter(
            Q(fcName__icontains=searchName) | Q(fcCode__icontains=searchName))
        return render(request, 'admin/flatcurrency.html', {'fcList': flatCurrs})
    return render(request, 'admin/flatcurrency.html', {'fcList': flatCurrs})



def saveFcurr(request):
    if request.method == "POST":
        form = FlatCurrencyForm(request.POST)
        if form.is_valid():
            fcSaved = form.save(commit=False)
            fcSaved.fcCreatedBy = User.objects.get(uUserName="SYSTEM")
            fcSaved.fcCreatedDate = datetime.now()
            fcSaved.fcStatus = 1
            fcSaved.save()
    form = FlatCurrencyForm()
    return redirect('adminSearchFC')


def getAllgateways(request):
    flatGateways = Gateway.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        flatGateways = Gateway.objects.filter(
            Q(gName__icontains=searchName) | Q(gCode__icontains=searchName))
        return render(request, 'admin/flatgateway.html', {'gList': flatGateways})
    return render(request, 'admin/flatgateway.html', {'gList': flatGateways})
    

def getAddgateways(request):
    if request.method == "POST":
        form = FlatGatewayForm(request.POST)
        if form.is_valid():
            gSaved = form.save(commit=False)
            gSaved.gCreatedBy = User.objects.get(uUserName="SYSTEM")
            gSaved.gCreatedDate = datetime.now()
            gSaved.gStatus = 1
            gSaved.save()
    form = FlatGatewayForm()
    return redirect('adminSearchFg')



def getShowPaymentWindow(request):
    pw= PaymentWindow.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        pw = PaymentWindow.objects.filter(
            Q(pMinute__icontains=searchName))
        return render(request, 'admin/paymentwindow.html', {'pwList': pw})
    return render(request, 'admin/paymentwindow.html', {'pwList': pw})
    
def getAddPaymentWindow(request):
    if request.method == "POST":
        form = PaymentWindowForm(request.POST)
        if form.is_valid():
            pSaved = form.save(commit=False)
            pSaved.pCreatedBy = User.objects.get(uUserName="SYSTEM")
            pSaved.pCreatedDate = datetime.now()
            pSaved.pStatus = 1
            pSaved.save()
    form = PaymentWindowForm()
    return redirect('adminShowPaymentWindow')



def showAllAdvt(request):
    ads= Advertisement.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        
        ads = Advertisement.objects.filter(aCreatedBy__uUserName__icontains=searchName)
        return render(request, 'admin/advertisement.html', {'advtList': ads})
    return render(request, 'admin/advertisement.html', {'advtList': ads})


def showAllTradeRequest(request):
    tr= TradeRequest.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        tr = TradeRequest.objects.filter(
            Q(tBuyer__uUserName__icontains=searchName) | Q(tSeller__uUserName__icontains=searchName))
        return render(request, 'admin/tradeRequest.html', {'trList': tr})
    return render(request, 'admin/tradeRequest.html', {'trList': tr})


def getAllUsers(request):
    user = User.objects.all()
    if request.method == "POST":
        searchName = request.POST.get('search')
        user = User.objects.filter(
            Q(uUserName__icontains=searchName) | Q(uEmail__icontains=searchName))
        return render(request, 'admin/allUsers.html', {'uList': user})
    return render(request, 'admin/allUsers.html', {'uList': user})


def saveUsers(request):
    if request.method == "POST":
        form = UserForm(request.POST, request.FILES)
        if form.is_valid():
            uSaved = form.save(commit=False)
            uSaved.uCreatedBy = User.objects.get(uUserName="SYSTEM")
            uSaved.uCreatedDate = datetime.now()
            uSaved.uStatus = 1
            uSaved.save()
    form = UserForm()
    return render(request, 'user/addU.html', {'form': form})


def updateUsers(request, id):
    user = User.objects.get(pk=id)

    if request.method == "POST":
        form = UserForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            uSaved = form.save(commit=False)
            uSaved.uUpdatedBy = User.objects.get(uUserName="SYSTEM")
            uSaved.uUpdatedDate = datetime.now()
            uSaved.uStatus = 1
            uSaved.save()
            users = User.objects.all()
            return render(request, 'user/userdetail.html', {'uList': users})
    form = UserForm()
    return render(request, 'user/userdetail.html', {'form': form, 'u': user})




def getShowApiPages(request):
    return render(request, 'admin/api-setting.html')



def getShowGenralSetting(request):
        return render(request, 'admin/genral-setting.html')
        

