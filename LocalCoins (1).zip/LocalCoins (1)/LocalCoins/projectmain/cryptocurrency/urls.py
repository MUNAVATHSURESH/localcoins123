from cryptocurrency import views
from django.urls import path

urlpatterns = [
    
    path('', views.getAllCCurrs,name="searchCC"),
    path('a/', views.saveCCurr, name="saveCC"),
    path('u/<slug:id>', views.updateCCurr, name ="updateCC"),
]
