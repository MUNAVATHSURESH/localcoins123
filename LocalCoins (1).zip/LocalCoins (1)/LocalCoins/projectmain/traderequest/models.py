from datetime import datetime
from django.db import models
from user.models import User
from cryptocurrency.models import CryptoCurrency
from flatcurrency.models import FlatCurrency
from advertisement.models import Advertisement

# Create your models here.
class TradeRequest(models.Model):
    tBuyer = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sBuyer', null=False)
    tSeller = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sSeller', null=False)
    tUniqueId = models.CharField(max_length=20, primary_key=True, null=False)
    tCCurrency = models.ForeignKey(
        CryptoCurrency, on_delete=models.CASCADE, related_name='%(class)sCryptoCurrency', null=False)
    tCurrency = models.ForeignKey(
        FlatCurrency, on_delete=models.CASCADE, related_name='%(class)sFlatCurrency', null=False)
    tCCAmount = models.FloatField(null=False)
    tCAmount = models.FloatField(null=False)
    tExchangeRate = models.FloatField(null=True)
    tMessage = models.CharField(max_length=400, null=True)
    tAdvertisement = models.ForeignKey(
        Advertisement, on_delete=models.CASCADE, related_name='%(class)sAdvertisement', null=False)
    tStatus = models.IntegerField(default=1, null=False)
    tCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    tCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    tUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    tUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
