from django.contrib import admin

from traderequest.models import TradeRequest

# Register your models here.


class TradeRequestAdmin(admin.ModelAdmin):
    list_display = [
        'tBuyer',
        'tSeller',
        'tUniqueId',
        'tCCurrency',
        'tCurrency',
        'tCCAmount',
        'tCAmount',
        'tExchangeRate',
        'tMessage',
        'tAdvertisement',
        'tStatus',
        'tCreatedBy',
        'tCreatedDate',
        'tUpdatedBy',
        'tUpdatedDate',
    ]


admin.site.register(TradeRequest, TradeRequestAdmin)
