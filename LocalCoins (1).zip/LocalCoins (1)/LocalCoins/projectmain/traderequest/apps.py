from django.apps import AppConfig


class TraderequestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'traderequest'
