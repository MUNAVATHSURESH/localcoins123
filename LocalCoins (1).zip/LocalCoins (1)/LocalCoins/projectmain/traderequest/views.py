from datetime import datetime
from django.shortcuts import redirect,render
from cryptocurrency.models import CryptoCurrency
from advertisement.models import Advertisement
from wallet.models import Wallet
from traderequest.forms import TradeRequestForm
import uuid
from traderequest.models import TradeRequest
from user.models import User
from django.db.models import Q

from django.contrib.auth.decorators import login_required
# Create your views here.
def tradeReportPages(request):
    return render(request,'traderequest/manage_trade_reports.html')


def tradeRequestPages(request):
    return render(request, 'traderequest/request.html')


@login_required
def newTradeRequest(request,id):
    ads = Advertisement.objects.get(id=id)
    ccList = CryptoCurrency.objects.all()
    if request.method == "POST":
        form = TradeRequestForm(request.POST)
        print('form ', form)
        if form.is_valid():
            trSaved = form.save(commit=False)
            if(ads.aType == 'BUY'):
                trSaved.tBuyer = User.objects.get(pk=request.user.uUserName)
                trSaved.tSeller = User.objects.get(pk=ads.aCreatedBy.uUserName)
            else:
                trSaved.tBuyer = User.objects.get(pk=ads.aCreatedBy.uUserName)
                trSaved.tSeller = User.objects.get(pk=request.user.uUserName)
            trSaved.tUniqueId = uuid.uuid1()
            trSaved.tCCurrency = ads.aCCurrency
            trSaved.tCurrency = ads.aCurrency
            trSaved.tExchangeRate = ads.aRate
            trSaved.tAdvertisement =ads
            trSaved.tStatus = 1
            trSaved.tCreatedBy = User.objects.get(pk=request.user.uUserName)
            trSaved.tCreatedDate = datetime.now()
            trSaved.save()
            return redirect('userPayTrade', trSaved.tUniqueId)
    form = TradeRequestForm()
    return render(request, 'traderequest/tradeRequest.html', {'form': form, 'ads': ads, 'ccList': ccList})


@login_required
def getUserTradeRequest(request):
    tr = TradeRequest.objects.filter(
        tCreatedBy__uUserName=request.user.uUserName)
    user = User.objects.get(pk=request.user.uUserName)
    ccList = CryptoCurrency.objects.all()
    return render(request, 'user/userTradeRequest.html', {'activeTr': tr.filter(tStatus=1), 'completedTr': tr.filter(tStatus=18), 'user': user, 'ccList': ccList})


@login_required
def payTradeRequest(request, id):
    trd = TradeRequest.objects.get(pk=id)
    ccList = CryptoCurrency.objects.all()
    return render(request, 'traderequest/payTradeRequest.html', {'trd': trd, 'ccList': ccList})


@login_required
def generateTradeReciept(request,id):
    trd = TradeRequest.objects.get(pk=id)
    ccList = CryptoCurrency.objects.all()
    buyerWallet = Wallet.objects.filter(
        Q(wCCurrency__ccName__icontains=trd.tCCurrency.ccName) & 
        Q(wUser__uUserName=trd.tBuyer.uUserName)
    ).get()
    sellerWallet = Wallet.objects.filter(
        Q(wCCurrency__ccName__icontains=trd.tCCurrency.ccName) &
        Q(wUser__uUserName=trd.tSeller.uUserName)
    ).get()
    if(trd.tStatus==1):
        preAmount = Wallet.objects.filter(
            Q(wCCurrency__ccName__icontains=trd.tCCurrency.ccName) &
            Q(wUser__uUserName=request.user.uUserName)
        ).get().wCCAmount
        print(buyerWallet)
        print(sellerWallet)
        buyerWallet.wCCAmount = buyerWallet.wCCAmount - trd.tCCAmount
        sellerWallet.wCCAmount = sellerWallet.wCCAmount + trd.tCCAmount
        buyerWallet.save()
        sellerWallet.save()
        postAmount = Wallet.objects.filter(
            Q(wCCurrency__ccName__icontains=trd.tCCurrency.ccName) &
            Q(wUser__uUserName=request.user.uUserName)
        ).get().wCCAmount
        advt = trd.tAdvertisement
        advt.aStatus=18
        advt.save()
        trd.tStatus = 18
        trd.save()
    else:
        postAmount = Wallet.objects.filter(
            Q(wCCurrency__ccName__icontains=trd.tCCurrency.ccName) &
            Q(wUser__uUserName=request.user.uUserName)
        ).get().wCCAmount
        if(trd.tAdvertisement.aType == 'BUY'):
            preAmount = postAmount+trd.tCCAmount
        else:
            preAmount = postAmount-trd.tCCAmount
    return render(request, 'traderequest/tradeReciept.html', {'trd': trd, 'ccList': ccList, 'preAmount': preAmount, 'postAmount': postAmount})
