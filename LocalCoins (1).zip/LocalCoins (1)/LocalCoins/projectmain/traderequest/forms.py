from django import forms

from traderequest.models import TradeRequest

class TradeRequestForm(forms.ModelForm):
    class Meta:
        model = TradeRequest
        fields = {'tCAmount', 'tCCAmount',
                   'tMessage'}