from traderequest import views
from django.urls import path

urlpatterns = [
    
    path('tradeReporturl/', views.tradeReportPages),
    path('tradeRequesturl/', views.tradeRequestPages),
]
