from django.contrib import admin

from trnType.models import TransactionType

# Register your models here.


class TransactionTypeAdmin(admin.ModelAdmin):
    list_display=[
        'trnType',
        'trnCode'

    ] 
admin.site.register(TransactionType,TransactionTypeAdmin)