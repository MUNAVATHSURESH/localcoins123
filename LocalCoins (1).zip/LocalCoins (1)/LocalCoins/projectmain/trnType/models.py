from django.db import models

# Create your models here.


class TransactionType(models.Model):
    trnType = models.CharField(max_length=30, primary_key=True)
    trnCode = models.CharField(max_length=2,null=False)
