from django import forms
from flatcurrency.models import FlatCurrency

class FlatCurrencyForm(forms.ModelForm):
    #fields with validations
    class Meta:
        model = FlatCurrency
        exclude = ('fcCreatedBy', 'fcCreatedDate',
                   'fcUpdatedBy', 'fcUpdatedDate','fcStatus')