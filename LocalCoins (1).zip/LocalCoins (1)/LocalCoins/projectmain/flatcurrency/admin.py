from django.contrib import admin

from flatcurrency.models import FlatCurrency



# Register your models here.
class FlatCurrencyAdmin(admin.ModelAdmin):
    list_display =[
        'fcName',
        'fcCode',
        'fcSymbol',
        'fcRate',
        'fcStatus',
        'fcCreatedBy',
        'fcCreatedDate',
        'fcUpdatedBy',
        'fcUpdatedDate',
    ]
admin.site.register(FlatCurrency, FlatCurrencyAdmin)



