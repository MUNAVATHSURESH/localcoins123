from datetime import datetime
from django.db import models
from user.models import User
# Create your models here.


class FlatCurrency(models.Model):
    fcName = models.CharField(max_length=30, primary_key=True)
    fcCode = models.CharField(max_length=10, null=False)
    fcSymbol = models.CharField(max_length=10, null=False)
    fcRate = models.FloatField(null=False)
    fcStatus = models.IntegerField(default=1, null=False)
    fcCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    fcCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    fcUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    fcUpdatedDate = models.DateTimeField(default=datetime.now, null=True)
