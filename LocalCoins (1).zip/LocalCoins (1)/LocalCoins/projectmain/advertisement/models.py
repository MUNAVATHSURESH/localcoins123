from django.db import models
from cryptocurrency.models import CryptoCurrency
from flatcurrency.models import FlatCurrency
from gateway.models import Gateway
from paymentwindow.models import PaymentWindow
from user.models import User
from datetime import datetime





# Create your models here.

class Advertisement(models.Model):
    aType = models.CharField(max_length=10, null=False)
    aCCurrency = models.ForeignKey(
        CryptoCurrency, on_delete=models.CASCADE, related_name='%(class)sCryptoCurrency', null=False)
    aPaymentMethod = models.ForeignKey(
        Gateway, on_delete=models.CASCADE, related_name='%(class)sGateways', null=False)
    aCurrency = models.ForeignKey(
        FlatCurrency, on_delete=models.CASCADE, related_name='%(class)sFlatCurrency', null=False)
    aMargin = models.FloatField(null=True)
    aPaymentWindow = models.ForeignKey(
        PaymentWindow, on_delete=models.CASCADE, related_name='%(class)sPaymentWindow',)
    aMinimumLimit = models.IntegerField(null=False)
    aMaximumLimit = models.IntegerField(null=False)
    aRate = models.FloatField(null=False)
    aPaymentDetails = models.CharField(max_length=400, null=True)
    aTradeOfTerm = models.CharField(max_length=400, null=True)
    aStatus = models.IntegerField(default=1, null=False)
    aCreatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sCreatedBy', null=False)
    aCreatedDate = models.DateTimeField(default=datetime.now, null=False)
    aUpdatedBy = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='%(class)sUpdatedBy', null=True)
    aUpdatedDate = models.DateTimeField(default=datetime.now, null=True)


