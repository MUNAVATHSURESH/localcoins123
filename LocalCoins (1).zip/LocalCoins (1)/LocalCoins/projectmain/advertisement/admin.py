from django.contrib import admin

from advertisement.models import Advertisement

# Register your models here.


class AdvertisementAdmin(admin.ModelAdmin):
    list_display =[
        'aType',
        'aCCurrency',
        'aPaymentMethod',
        'aCurrency',
        'aMargin',
        'aPaymentWindow',
        'aMinimumLimit',
        'aMaximumLimit',
        'aRate',
        'aPaymentDetails',
        'aTradeOfTerm',
        'aStatus',
        'aCreatedBy',
        'aCreatedDate',
        'aUpdatedBy',
        'aUpdatedDate',
    ]


admin.site.register(Advertisement, AdvertisementAdmin)
