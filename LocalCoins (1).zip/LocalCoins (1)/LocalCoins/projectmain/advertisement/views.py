from datetime import datetime
from django.shortcuts import render
from advertisement.forms import AdvertisementForm

from cryptocurrency.models import CryptoCurrency
from flatcurrency.models import FlatCurrency
from gateway.models import Gateway
from advertisement.models import Advertisement
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from paymentwindow.models import PaymentWindow

from django.contrib.auth.decorators import login_required
from user.models import User

# Create your views here.


def addAdvt(request):
    return render(request, "advertisement/advertise_limit.html")


def updateAdvt(request):
    return render(request, "advertisement/advertise_limit.html")


def showMyAdvt(request):
    return render(request, "advertisement/advertise_limit.html")


def advertiselimitPages(request):
    return render(request, "advertisement/advertise_limit.html")


def showAllAdvtuser(request):
    return render(request, 'advertisement/advertisement.html')


def showAds(request):
    cryptoCurr = CryptoCurrency.objects.all()
    gatewayType = Gateway.objects.all()
    flatCurr = FlatCurrency.objects.all()
    advtList = Advertisement.objects.filter(aStatus=1)

    if request.method == "POST":
        buySell = request.POST.get('aType')
        cryCurr = request.POST.get('aCCurrency')
        gateway = request.POST.get('aPaymentMethod')
        curr = request.POST.get('aCurrency')
        amount = request.POST.get('amount')

        cryCurrName = CryptoCurrency.objects.get(pk=cryCurr)
        advtList = Advertisement.objects.filter(
            aType__icontains=buySell,
            aCCurrency__pk=cryCurr,
            aStatus=1)

        if(gateway):
            advtList = advtList.filter(aPaymentMethod__pk=gateway)
        if(curr):
            advtList = advtList.filter(aCurrency__pk=curr)

        if amount:
            advtList = advtList.filter(
                aMaximumLimit__gte=amount,
                aMinimumLimit__lte=amount)

        page = request.POST.get('page', 1)
        paginator = Paginator(advtList, 1)
        try:
            advtList = paginator.page(page)
        except PageNotAnInteger:
            advtList = paginator.page(1)
        except EmptyPage:
            advtList = paginator.page(paginator.num_pages)

        return render(request, 'advertisement/userShowAds.html', {'cC': cryptoCurr, 'gT': gatewayType, 'fC': flatCurr, 'advtList': advtList, 'buySell': buySell, 'cryCurrName': cryCurrName})
    return render(request, 'advertisement/userShowAds.html', {'cC': cryptoCurr, 'gT': gatewayType, 'fC': flatCurr, 'advtList': advtList})


def showAdsByLink(request, buySell, cryCurr):
    cryptoCurr = CryptoCurrency.objects.all()
    gatewayType = Gateway.objects.all()
    flatCurr = FlatCurrency.objects.all()
    print('cryCurr', cryCurr)
    cryCurrName = CryptoCurrency.objects.get(pk=cryCurr)

    advtList = Advertisement.objects.filter(
        aType__icontains=buySell,
        aCCurrency__pk=cryCurr,
        aStatus=1)

    page = request.POST.get('page', 1)
    paginator = Paginator(advtList, 1)
    try:
        advtList = paginator.page(page)
    except PageNotAnInteger:
        advtList = paginator.page(1)
    except EmptyPage:
        advtList = paginator.page(paginator.num_pages)

    return render(request, 'advertisement/userShowAds.html', {'cC': cryptoCurr, 'gT': gatewayType, 'fC': flatCurr, 'advtList': advtList, 'buySell': buySell, 'cryCurrName': cryCurrName})


@login_required
def saveUserAds(request) :
    cryptoCurr = CryptoCurrency.objects.all()
    gatewayType = Gateway.objects.all()
    flatCurr = FlatCurrency.objects.all()
    paymentWindow = PaymentWindow.objects.all()

    if request.method == "POST":
        form = AdvertisementForm(request.POST)
        print('form ',form)
        if form.is_valid():
            aSaved = form.save(commit=False)
            aSaved.aCreatedBy = User.objects.get(
                uUserName=request.user.uUserName)
            aSaved.aCreatedDate = datetime.now()
            aSaved.aStatus = 1
            aSaved.save()
    form = AdvertisementForm()
    return render(request, 'user/userNewAds.html', {'form': form, 'cC': cryptoCurr, 'gT': gatewayType, 'fC': flatCurr, 'pW':paymentWindow})
