from advertisement import views
from django.urls import path

urlpatterns = [
    path('home/', views.advertiselimitPages),
    # path('', views.showAllAdvtuser),
    path('shsearch/', views.showAds, name ='showads'),
    path('shsearch/<slug:buySell>/<slug:cryCurr>',
         views.showAdsByLink, name='showAdsByLink'),
    path('add/', views.addAdvt, name ='addads'),
    path('update/', views.updateAdvt, name ='updateAds'),
    path('sh/', views.showMyAdvt, name ='showadsqw'),
]
